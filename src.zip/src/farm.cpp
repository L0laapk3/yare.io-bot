#include "farm.h"

#include "objects.h"
#include "position.h"

#include <algorithm>
#include <cmath>




void farm() {
	if (available.size() <= 0)
		return;

	float bsDist = dist(bases[0], stars[0]);
	// auto P1 = normalize(bases[0].position);

	// Position P2A = bases[0] + normalize(stars[0] - bases[0]) * 396;
	// Position P2B = bases[0] + normalize(stars[0] - bases[0]) * (bsDist - 198);

	// float travelTime = std::ceilf((bsDist - 598.5) / 20) - 1;

	// float farmer2CycleTime = 2 * (10 + travelTime);
	// float perfectRatio = 1 - 10 / (10 + farmer2CycleTime);

	
	// std::sort(available.begin(), available.end(), [](auto* a, auto* b){
	// 	return (a->db - a->ds) - (b->db - b->ds);
	// });
	// std::vector<Spirit*>::iterator farmers1End;
	// Position haulA, targetA;
	// if (available.size() < 3 || (available.size() == 3 && bases[0].energy <= 1.8 * available[0]->energyCapacity)) {
	// 	farmers1End = available.begin();
	// 	haulA = P1;
	// 	targetA = bases[0];
	// } else {
	// 	haulA = P2A;
	// 	targetA = P1;


	// }
}