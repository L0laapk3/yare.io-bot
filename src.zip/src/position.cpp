
#include "position.h"

#include <math.h>



Position Position::operator+(Position v) {
	return Position{ x + v.x, y + v.y };
}
Position Position::operator-(Position v) {
	return Position{ x - v.x, y - v.y };
}
Position Position::operator*(float a) {
	return Position{ x * a, y * a };
}
Position Position::operator/(float a) {
	return Position{ x / a, y / a };
}
float dot(Position u, Position v) {
	return u.x * v.x + u.y * v.y;
}
float norm(Position u) {
	return sqrtf(dot(u, u));
}
Position normalize(Position u) {
	return u / norm(u);
}
float dist(Position u, Position v) {
	return norm(u - v);
}
Position inDirection(Position u, Position v, float d) {
	return u + normalize(v - u) * d;
}