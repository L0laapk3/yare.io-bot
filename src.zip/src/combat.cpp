#include "combat.h"

#include "objects.h"

#include <algorithm>


void processAttacks() {
	for (auto& s : enemies)
		if (s.energy > 0) {
			if (dist(s, bases[0]) <= s.range)
				goto attack;
			// for (auto& t : units)
			// 	if (dist(s, t) <= s.range)
			// 		goto attack;
			continue;

			attack:
			s.usedEnergize = true;
			s.energy = std::max(s.energy - s.size, 0);
		}

	for (auto& s : units)
		if (s.energy > 0) {
			if (dist(s, bases[1]) <= s.range) {
				s.energizeBase(bases[1]);
				s.energy -= std::min(s.energy, s.size);
				s.usedEnergize = true;
				continue;
			}
			for (auto& t : enemies)
				if (t.energy >= 0 && dist(s, t) <= s.range) {
					s.energize(t);
					t.energy -= 2 * std::min(s.energy, s.size);
					s.energy -= std::min(s.energy, s.size);
					s.usedEnergize = true;
					break;
				}
		}
}