#pragma once

struct Position {
	float x, y;

	Position operator+(Position v);
	Position operator-(Position v);
	Position operator*(float a);
	Position operator/(float a);
};

float dot(Position u, Position v);
float norm(Position u);
Position normalize(Position u);
float dist(Position u, Position v);
Position inDirection(Position u, Position v, float d);
