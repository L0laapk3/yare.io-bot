#include "objects.h"

#include "interface.h"

#include <algorithm>



std::vector<Star> stars;
std::vector<Base> bases;
std::vector<Spirit> units;
std::vector<Spirit*> available;
std::vector<Spirit> enemies;

void parseTick() {
	stars.clear();
	bases.clear();
	units.clear();
	available.clear();
	enemies.clear();

	int bCount = Interface::baseCount();
	for (int i = 0; i < bCount; i++) {
		if (Interface::baseHp(i) <= 0)
			continue;
		bases.push_back({
			{ Interface::basePositionX(i), Interface::basePositionY(i) },
			.index = i,
			.size = Interface::baseSize(i),
			.energyCapacity = Interface::baseEnergyCapacity(i),
			.energy = Interface::baseEnergy(i),
		});
	}

	int stCount = Interface::starCount();
	for (int i = 0; i < stCount; i++) {
stars.push_back({
	{ Interface::starPositionX(i), Interface::starPositionY(i) },
});
	}
	std::sort(stars.begin(), stars.end(), [&](auto& a, auto& b){
		return dist(a, bases[0]) < dist(b, bases[0]);
	});

	int sCount = Interface::spiritCount();
	for (int i = 0; i < sCount; i++) {
		if (Interface::spiritHp(i) <= 0)
			continue;
		Spirit spirit{
			{ Interface::spiritPositionX(i), Interface::spiritPositionY(i) },
			.index = i,
			.size = Interface::spiritSize(i),
			.shape = Interface::spiritShape(i),
			.energyCapacity = Interface::spiritEnergyCapacity(i),
			.energy = Interface::spiritEnergy(i),
		};
		spirit.db = dist(spirit, bases[0]);
		spirit.ds = dist(spirit, stars[0]);
		spirit.deb = dist(spirit, bases[1]);
		spirit.des = dist(spirit, stars[1]);

		if (Interface::spiritIsFriendly(i)) {
			units.push_back(spirit);
			available.push_back(&units[units.size() - 1]);
		} else
			enemies.push_back(spirit);
	}
}



void Spirit::energize(Spirit& s) {
	Interface::spiritEnergize(index, s.index);
}
void Spirit::energizeBase(Base& b) {
	Interface::spiritEnergizeBase(index, b.index);
}
void Spirit::move(Position& p) {
	Interface::spiritMove(index, p.x, p.y);
}
void Spirit::merge(Spirit& s) {
	Interface::spiritMerge(index, s.index);
}
void Spirit::divide() {
	Interface::spiritDivide(index);
}
void Spirit::jump(Position& p) {
	Interface::spiritJump(index, p.x, p.y);
}
void Spirit::shout(const char* str) {
	Interface::spiritShout(index, str);
}