
#include "interface.h"
#include "objects.h"
#include "combat.h"
#include "farm.h"



EXPORT("tick")
void tick() {
	parseTick();
	
	processAttacks();

	farm();
}