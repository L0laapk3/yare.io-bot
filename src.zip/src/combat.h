#pragma once

#include "objects.h"

void processAttacks();
