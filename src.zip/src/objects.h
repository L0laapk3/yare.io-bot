#pragma once

#include "position.h"

#include <vector>


enum Shape {
	circle = 0,
	square = 1,
	triangle = 2,
};


struct Object {
	Position position;
	operator Position() { return position; };
};

struct Star : Object {
};

struct Base : Object {
	int index;
	int size;
	int energyCapacity;
	int energy;
};

struct Spirit : Object {
	int index;
	int size;
	Shape shape;
	int energyCapacity;
	int energy;
	bool usedEnergize = false;
	bool usedMove = false;
	const int range = 200;
	float db;
	float ds;
	float deb;
	float des;

	void energize(Spirit&);
	void energizeBase(Base&);
	void move(Position&);
	void merge(Spirit&);
	void divide();
	void jump(Position&);
	void shout(const char*);
};


extern std::vector<Star> stars;
extern std::vector<Base> bases;
extern std::vector<Spirit> units;
extern std::vector<Spirit*> available;
extern std::vector<Spirit> enemies;

void parseTick();
